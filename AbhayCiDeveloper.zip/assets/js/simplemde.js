$(function() {
  'use strict';

  /*simplemde editor*/
  if ($("#simpleMdeExample1").length) {
    var simplemde = new SimpleMDE({
      element: $("#simpleMdeExample1")[0]
    });
  }

   /*simplemde editor*/
  if ($("#simpleMdeExample2").length) {
    var simplemde = new SimpleMDE({
      element: $("#simpleMdeExample2")[0]
    });
  }
   /*simplemde editor*/
  if ($("#simpleMdeExample3").length) {
    var simplemde = new SimpleMDE({
      element: $("#simpleMdeExample3")[0]
    });
  }

});