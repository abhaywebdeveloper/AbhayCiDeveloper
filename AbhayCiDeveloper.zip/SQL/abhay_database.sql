-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 27, 2022 at 09:22 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `abhay_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `nickname` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permision` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`permision`)),
  `desc` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `nickname`, `name`, `permision`, `desc`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Admin', NULL, 'Administrator users can perform any action.', NULL, NULL),
(2, 'user', 'User', NULL, 'Read, Write can perform any action.', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_activity` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `timestamp` int(11) NOT NULL,
  `data` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `last_activity`, `timestamp`, `data`) VALUES
('0990a1f2473033defc8717074d683f8aa1c5b9ad', NULL, '::1', NULL, '', 1658211734, '__ci_last_regenerate|i:1658211734;'),
('09d8db10e7395805b55447fa739ac2394e41cb21', NULL, '::1', NULL, '', 1658949070, '__ci_last_regenerate|i:1658949070;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"7a796a260d6b9361bd59ecd4ea0d00e7\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('10d786c9f55116a97ab11b724523341d82059aee', NULL, '::1', NULL, '', 1658945351, '__ci_last_regenerate|i:1658945351;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"7a796a260d6b9361bd59ecd4ea0d00e7\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('12ac6bf09b99f926858165481aa53c9e4b91a99f', NULL, '::1', NULL, '', 1658942123, '__ci_last_regenerate|i:1658942123;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"7a796a260d6b9361bd59ecd4ea0d00e7\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('19d0c7dbb25a9eb78093edfca389fb8831c60ff0', NULL, '::1', NULL, '', 1658939442, '__ci_last_regenerate|i:1658939442;'),
('1c50e2a707f0a4bd59233ccf924225d6e1852af3', NULL, '::1', NULL, '', 1658943180, '__ci_last_regenerate|i:1658943180;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"7a796a260d6b9361bd59ecd4ea0d00e7\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('2af550305eb29036b15d4e052cb8e5d6ceea746a', NULL, '::1', NULL, '', 1658945997, '__ci_last_regenerate|i:1658945997;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"7a796a260d6b9361bd59ecd4ea0d00e7\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('34c390fd6f6f43564e60d2a827e14d2c5a4a7d1f', NULL, '::1', NULL, '', 1658222557, '__ci_last_regenerate|i:1658222557;'),
('38118bd8a2f6d18895aeb96d976c97da291c5a4f', NULL, '::1', NULL, '', 1658940249, '__ci_last_regenerate|i:1658940249;'),
('412f57cee36421e5da309a26d38eca7fe78ba8c7', NULL, '::1', NULL, '', 1658938044, '__ci_last_regenerate|i:1658938044;'),
('440b9b9fcccf104be40a8c64b930e73e6a2b2fff', NULL, '::1', NULL, '', 1658946338, '__ci_last_regenerate|i:1658946338;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"7a796a260d6b9361bd59ecd4ea0d00e7\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('45fb1fe521d54f6e627f86dde509f4f5a30909d6', NULL, '::1', NULL, '', 1658216567, '__ci_last_regenerate|i:1658216523;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:0:\"\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"2f01618053cddf6b97f4f88df0d2d6af\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('4a4852ee0297bafaec6a89b2c53d288f2bcbe89e', NULL, '::1', NULL, '', 1658223452, '__ci_last_regenerate|i:1658223365;'),
('4cdfd158255e0e19b9dd4e7aeb0bd770b810fd32', NULL, '::1', NULL, '', 1658945692, '__ci_last_regenerate|i:1658945692;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"7a796a260d6b9361bd59ecd4ea0d00e7\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('5077660124db0d4afcd57a6a3726c67857df9cac', NULL, '::1', NULL, '', 1658936015, '__ci_last_regenerate|i:1658936015;'),
('51fbdee0a08d16180191e20c10b40c2795af7531', NULL, '::1', NULL, '', 1658210295, '__ci_last_regenerate|i:1658210295;'),
('5660d33c2628690bd473b00f1830adfa4b2116c2', NULL, '::1', NULL, '', 1658225551, '__ci_last_regenerate|i:1658225370;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"2f01618053cddf6b97f4f88df0d2d6af\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('5f3b0efe188bd81a747da3364a78a07230b99490', NULL, '::1', NULL, '', 1658945039, '__ci_last_regenerate|i:1658945039;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"7a796a260d6b9361bd59ecd4ea0d00e7\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('69ad740e88aae88721663ccea216f98d14699a4d', NULL, '::1', NULL, '', 1658949541, '__ci_last_regenerate|i:1658949541;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"7a796a260d6b9361bd59ecd4ea0d00e7\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('6f3f2a69e6dee5791a393d7fb949644287ac51fe', NULL, '::1', NULL, '', 1658941124, '__ci_last_regenerate|i:1658941124;'),
('6f73e0e814df6ede23b81bd368de1cb147528a7c', NULL, '::1', NULL, '', 1658949709, '__ci_last_regenerate|i:1658949541;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"7a796a260d6b9361bd59ecd4ea0d00e7\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('70818e8b8b9acc284621a8e8710b202a6615d38a', NULL, '::1', NULL, '', 1658947551, '__ci_last_regenerate|i:1658947551;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"7a796a260d6b9361bd59ecd4ea0d00e7\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('760adaccb64d3d9f03c309c61a3f118714439c08', NULL, '::1', NULL, '', 1658943832, '__ci_last_regenerate|i:1658943832;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"7a796a260d6b9361bd59ecd4ea0d00e7\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('775648ed0da33813d2cf64a41f41ec9b6966fc3e', NULL, '::1', NULL, '', 1658942852, '__ci_last_regenerate|i:1658942852;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"7a796a260d6b9361bd59ecd4ea0d00e7\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('77a461ba1daf33e9be0b4474ebf9edf3c4ad9f76', NULL, '::1', NULL, '', 1658211913, '__ci_last_regenerate|i:1658211901;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:0:\"\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"2f01618053cddf6b97f4f88df0d2d6af\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('7924f28f6041965f72ea4b74d424853b7d57fb5b', NULL, '::1', NULL, '', 1658944152, '__ci_last_regenerate|i:1658944152;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"7a796a260d6b9361bd59ecd4ea0d00e7\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('7b63fb7cd4a459d0e8965f3c1de38d9887204e04', NULL, '::1', NULL, '', 1658211891, '__ci_last_regenerate|i:1658211841;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:0:\"\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"2f01618053cddf6b97f4f88df0d2d6af\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('7e7420312c1662264d8e2c6dedcf7d7967f56ed3', NULL, '::1', NULL, '', 1658948253, '__ci_last_regenerate|i:1658948253;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"7a796a260d6b9361bd59ecd4ea0d00e7\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('806e975df686757516e935993302a366321013a9', 1, '::1', NULL, '', 1658209108, '__ci_last_regenerate|i:1658209108;'),
('81190e86e7cc7b845fe49da537254038aa79d458', NULL, '::1', NULL, '', 1658224379, '__ci_last_regenerate|i:1658224379;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"2f01618053cddf6b97f4f88df0d2d6af\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('81978cecb3975fc099099fe00c0c150d9c8bb8cf', NULL, '::1', NULL, '', 1658937297, '__ci_last_regenerate|i:1658937297;'),
('879fd10d5897268ca83fd61be4aaa7f540bf82dd', NULL, '::1', NULL, '', 1658209809, '__ci_last_regenerate|i:1658209809;'),
('88046b43dc306c9954ccc3cd21eb17f197ea4497', NULL, '::1', NULL, '', 1658947853, '__ci_last_regenerate|i:1658947853;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"7a796a260d6b9361bd59ecd4ea0d00e7\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('88268dc3c496f9b33d5c7cd1952db77443eeac8a', NULL, '::1', NULL, '', 1658223464, '__ci_last_regenerate|i:1658223464;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:0:\"\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"2f01618053cddf6b97f4f88df0d2d6af\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('9942b610c78b52af59b88d486192260884039dc3', NULL, '::1', NULL, '', 1658941425, '__ci_last_regenerate|i:1658941425;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"7a796a260d6b9361bd59ecd4ea0d00e7\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('9f1c6986b71126f589a8904743dc6ce9322bef03', NULL, '::1', NULL, '', 1658938708, '__ci_last_regenerate|i:1658938708;'),
('a0a4cedafca4378103c208dab5d2411b3569f0b7', NULL, '::1', NULL, '', 1658939051, '__ci_last_regenerate|i:1658939051;'),
('a54fd52ff3c3cca8825c00fc4bec915e9c8ae13a', NULL, '::1', NULL, '', 1658223885, '__ci_last_regenerate|i:1658223885;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"2f01618053cddf6b97f4f88df0d2d6af\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('a83bf51a431beed693b2341a22ccab15a7389252', NULL, '::1', NULL, '', 1658223244, '__ci_last_regenerate|i:1658223244;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"2f01618053cddf6b97f4f88df0d2d6af\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('aea05facd98cb1c3ba71c6bc30e621e81015069c', NULL, '::1', NULL, '', 1658211702, '__ci_last_regenerate|i:1658211702;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:0:\"\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"2f01618053cddf6b97f4f88df0d2d6af\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('b033069ab825c156e58240e0df3a0b10e30c6705', NULL, '::1', NULL, '', 1658214940, '__ci_last_regenerate|i:1658214940;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:0:\"\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"2f01618053cddf6b97f4f88df0d2d6af\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('b548975f82052e85077db0abcd3225a1e9563ad5', NULL, '::1', NULL, '', 1658225370, '__ci_last_regenerate|i:1658225370;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"2f01618053cddf6b97f4f88df0d2d6af\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('b904490f5af37b74d808443deec825d72f05d47d', NULL, '::1', NULL, '', 1658224760, '__ci_last_regenerate|i:1658224760;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"2f01618053cddf6b97f4f88df0d2d6af\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('b9c24ec7e6138310065db0de22ac1562237bc121', NULL, '::1', NULL, '', 1658222866, '__ci_last_regenerate|i:1658222866;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:0:\"\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"2f01618053cddf6b97f4f88df0d2d6af\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('bea1f845a2a563adf98031dfd3f6cb5732b4209a', NULL, '::1', NULL, '', 1658944670, '__ci_last_regenerate|i:1658944670;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"7a796a260d6b9361bd59ecd4ea0d00e7\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('bee669c4d3c2223558e6f91d9d80ceda9cea3f04', NULL, '::1', NULL, '', 1658948769, '__ci_last_regenerate|i:1658948769;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"7a796a260d6b9361bd59ecd4ea0d00e7\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('c880414940001c0e86e55978dda398e0e27c8b6c', NULL, '::1', NULL, '', 1658947182, '__ci_last_regenerate|i:1658947182;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"7a796a260d6b9361bd59ecd4ea0d00e7\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('ccc66fd81604f774e969f7ef15c853e6c6927922', NULL, '::1', NULL, '', 1658937676, '__ci_last_regenerate|i:1658937676;'),
('cda1403bd163ac6e80058f37d636ea062296f989', NULL, '::1', NULL, '', 1658215243, '__ci_last_regenerate|i:1658215243;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:0:\"\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"2f01618053cddf6b97f4f88df0d2d6af\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('d6079496e6b9a3e29f7ae512624ccbe21d48a7d6', NULL, '::1', NULL, '', 1658942440, '__ci_last_regenerate|i:1658942440;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"7a796a260d6b9361bd59ecd4ea0d00e7\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('d821d5165d31abe2c30f638739f194567eb90e13', NULL, '::1', NULL, '', 1658216523, '__ci_last_regenerate|i:1658216523;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:0:\"\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"2f01618053cddf6b97f4f88df0d2d6af\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('def0dd0f3d14a5a377122e500aac1e315003cbb6', NULL, '::1', NULL, '', 1658939936, '__ci_last_regenerate|i:1658939936;'),
('e0c4297d27744f724b5a3a197e8ddd0fd6f2e331', NULL, '::1', NULL, '', 1658946744, '__ci_last_regenerate|i:1658946744;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"7a796a260d6b9361bd59ecd4ea0d00e7\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('e0e22528e011ee16c53302e53891de930da18ca7', NULL, '::1', NULL, '', 1658211833, '__ci_last_regenerate|i:1658211734;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:0:\"\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"2f01618053cddf6b97f4f88df0d2d6af\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('ebcd07b765072f41d180a94f51b551232d6e8def', NULL, '::1', NULL, '', 1658225066, '__ci_last_regenerate|i:1658225066;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:36:\"c16eb86a764fb37c2d7e1e8f476b1688.png\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"2f01618053cddf6b97f4f88df0d2d6af\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('f9aedf51e72d11f5256fe297681d5243dd27f783', NULL, '::1', NULL, '', 1658940624, '__ci_last_regenerate|i:1658940624;'),
('fa599552a98295e1cb495a5b38ba22213bd0e240', NULL, '::1', NULL, '', 1658212071, '__ci_last_regenerate|i:1658212065;isLogged|b:1;id|s:1:\"1\";name|s:11:\"abhay Admin\";email|s:15:\"abhay@gmail.com\";phone|s:10:\"8750908036\";profile|s:0:\"\";email_verified_at|s:19:\"2021-01-02 15:27:36\";otp|s:0:\"\";otp_verified|s:1:\"1\";otp_verified_at|s:19:\"2022-05-21 10:38:36\";password|s:32:\"2f01618053cddf6b97f4f88df0d2d6af\";remember_token|N;role_id|s:1:\"1\";created_at|s:19:\"2021-01-02 15:12:08\";updated_at|s:19:\"2021-01-02 15:27:36\";'),
('ff174eef29f3131f92966c660ddc8b88cf9a30b3', NULL, '::1', NULL, '', 1658222161, '__ci_last_regenerate|i:1658222161;');

-- --------------------------------------------------------

--
-- Table structure for table `sites`
--

CREATE TABLE `sites` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `panelId` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keys` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `favicon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loader` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'A V',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` bigint(20) NOT NULL,
  `parent_id` bigint(20) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `short_content` text NOT NULL,
  `short_content_h` varchar(400) NOT NULL,
  `category_icon` varchar(300) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0 => Disabled, 1 => Enabled'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `parent_id`, `title`, `slug`, `content`, `short_content`, `short_content_h`, `category_icon`, `created_at`, `status`) VALUES
(1, 0, 'BEVERAGES', 'beverages', '', '', '', 'beverages.jpeg', '2022-07-27 18:21:06', 1),
(2, 1, 'COFFEE', 'coffee', '', '', '', 'coffee.jpeg', '2022-07-27 18:01:43', 1),
(3, 1, 'TEA', 'tea', '', '', '', 'tea.jpeg', '2022-07-27 18:02:47', 1),
(4, 1, 'SHAKES', 'shakes', '', '', '', 'shakes.jpeg', '2022-07-27 18:03:59', 1),
(5, 1, 'HOT COFFEE', 'hot-coffee', '', '', '', 'tea.jpeg', '2022-07-27 18:04:24', 1),
(6, 1, 'COLA', 'cola', '', '', '', 'tea.jpeg', '2022-07-27 18:04:50', 1),
(7, 0, 'MEALS', 'meals', '', '', '', 'tea.jpeg', '2022-07-27 18:05:08', 1),
(8, 0, 'DRINKS', 'drinks', '', '', '', 'tea.jpeg', '2022-07-27 18:05:28', 1),
(9, 0, 'DESERT', 'desert', '', '', '', 'tea.jpeg', '2022-07-27 18:05:46', 1),
(10, 0, 'CHICKEN', 'chicken', '', '', '', 'tea.jpeg', '2022-07-27 18:06:02', 1),
(11, 8, 'd-1', 'd-1', '', '', '', '', '2022-07-27 18:40:44', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `otp` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `otp_verified` tinyint(4) NOT NULL DEFAULT 0,
  `otp_verified_at` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` tinyint(3) UNSIGNED NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `profile`, `email_verified_at`, `otp`, `otp_verified`, `otp_verified_at`, `password`, `remember_token`, `role_id`, `created_at`, `updated_at`) VALUES
(1, 'abhay Admin', 'abhay@gmail.com', '8750908036', 'c16eb86a764fb37c2d7e1e8f476b1688.png', '2021-01-02 09:57:36', '', 1, '2022-05-21 10:38:36', '7a796a260d6b9361bd59ecd4ea0d00e7', NULL, 1, '2021-01-02 15:12:08', '2021-01-02 09:57:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`(768));

--
-- Indexes for table `sites`
--
ALTER TABLE `sites`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_phone_unique` (`phone`),
  ADD KEY `users_role_id_foreign` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sites`
--
ALTER TABLE `sites`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
