<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	public $refer;
	public function __construct(){
		parent::__construct();
        $this->ci = & get_instance();
        $this->ci->load->model('admin/Categorymodel', 'Categorymodel');
	}
    public function index()
    {
        $alll = $this->ci->Categorymodel->GetPackage();
        $datacategoery = $this->ci->Categorymodel->getModuleByFild('tbl_category','parent_id','0');        
        $this->load->view('website/index',compact('datacategoery','alll'));
    }
    public function category()
    {
        $slug = basename($this->uri->segment(2), ".html");

        $slugDetales = $this->ci->Categorymodel->getBySlug('tbl_category',$slug);
        $id = $slugDetales->id;
         $parent_id= $slugDetales->parent_id;
        if($parent_id ==0)
        {
            $alll = $this->ci->Categorymodel->getById('tbl_category','parent_id',$id);
        }
        else{
            $alll = $this->ci->Categorymodel->getById('tbl_category','id',$id);
        }
        // echo "<pre>";
        // print_r($alll);
        // die();

        $datacategoery = $this->ci->Categorymodel->getModuleByFild('tbl_category','parent_id','0');        
        $this->load->view('website/index',compact('datacategoery','alll'));
    }
    
    public function Not_Found()
    {
        $this->load->view('PageNotFound');
    }
    public function commingSoon()
    {
        
        $this->load->view('commingsoon');
    }   


}