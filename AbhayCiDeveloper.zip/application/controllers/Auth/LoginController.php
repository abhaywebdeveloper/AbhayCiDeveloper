<?php
defined('BASEPATH') or exit('No direct script access allowed');

class LoginController extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->helper('security');

    }
    public function loginPage()
    {
        $this->_loggedOrNot();
        $this->load->view('login/login');

    }
    public function loginCheckPageFunction()
    {
        $this->form_validation->set_error_delimiters('<strong><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;Report!&nbsp;&nbsp;</strong>');
        $this->form_validation->set_rules('email', 'Username', 'trim|required');
        $this->form_validation->set_rules('password', 'Password', 'trim|required'); 
        if ($this->form_validation->run() == FALSE) {
            $result['status'] = false;
            $result['message'] = validation_errors();
            $result['message'] = $this->form_validation->error_array();
        } 
        else{
            $username = $this->security->xss_clean($this->input->post('email'));
            $sessionVariable = array(
                'email' => $username,
            );
            //load authentication library to check username and password
            $this->load->library('authentication');
            $isUserFound = $this->authentication->checkUser($sessionVariable);
            if ($isUserFound) {
                $password = md5($this->security->xss_clean($this->input->post('password')));
                if ($isUserFound['password']==$password) {
                    $this->session->set_userdata(['isLogged' => true, 'id' => $isUserFound['id']]);
                    $this->session->set_userdata($isUserFound);
                    $result['status'] = true;
                    $result['message'] = 'login';
                } else {
                    $array = [
                        'password' => 'password not matched our records',
                    ];
                    $result['status'] = false;
                    $result['message'] = $array; 
                }
            } else {
                $array = [
                    'email' => 'Username not matched our records',
                ];
                $result['status'] = false;
                $result['message'] =  $array; 
                
            }        
        }
        echo json_encode($result);
    }

    

    public function loggedout()
    {
        $this->session->sess_destroy();
        redirect(base_url('admin'));
    }
    private function _loggedOrNot()
    {
        $logged = $this->session->userdata();
        if (!empty($logged['isLogged'])) {
            if ($logged['isLogged'] == true) {
                redirect(base_url() . 'Admin/dashboard');
            }
        }
    }
}
