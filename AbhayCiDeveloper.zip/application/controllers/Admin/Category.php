<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Category extends CI_Controller {
    public $refer;
    public function __construct() {
        parent::__construct();
        $this->ci = & get_instance();
        $this->ci->load->model('Auth/AdminModel', 'auth');
        $this->load->library('form_validation');
        $this->load->helper('security');
        $this->load->library('user_agent');
        $this->_loggedOrNot();
        $this->_sessionUpdate();
        $this->refer = $this->agent->referrer();
        $this->ci->load->model('admin/Categorymodel', 'Categorymodel');
    }
    private function _sessionUpdate() {
        $data = $this->ci->auth->getUserDetails();
        $this->session->set_userdata($data);
    }
    private function _loggedOrNot() {
        $logged = $this->session->userdata();
        if (!empty($logged['isLogged'])) {
            if ($logged['isLogged'] != true) {
                redirect(base_url('admin/dashboard'));
            }
        } else {
            redirect(base_url('admin'));
        }
    }
    public function index() {
        $datacategoery = $this->ci->Categorymodel->GetPackage();
        $this->load->view('admin/category',compact('datacategoery'));
    }
    public function add() {
        $datacategoery = $this->ci->Categorymodel->getCategoriesByParentId();      
        $this->load->view('admin/categoryAdd',compact('datacategoery'));
    }
    public function insertData() 
    {
        $this->form_validation->set_error_delimiters('<strong>Danger!</strong> ',);
        $this->form_validation->set_rules('title', 'Title', 'trim|required');
        $this->form_validation->set_rules('slug', 'Slug', 'trim|required');
        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata(['error' => validation_errors() ]);
            redirect(base_url('Admin/Category/add'));
            exit();
        } else {
            $title = $this->security->xss_clean($this->input->POST('title'));
            $short_content = $this->security->xss_clean($this->input->POST('short_content'));
            $status = $this->security->xss_clean($this->input->POST('status'));
            $content = $this->security->xss_clean($this->input->POST('content'));
            $parent_id = $this->security->xss_clean($this->input->POST('parent_id'));

            $url = $this->security->xss_clean($this->input->POST('slug'));
            if (empty($url)) {
                $url = $title;
            }
            $slug = preg_replace('/[^a-z0-9]+/i', '-', trim(strtolower($url)));
            $selectQuery = $this->db->query("SELECT * FROM tbl_category WHERE slug LIKE '$slug%'");
            if ($selectQuery->num_rows() > 0) {
                foreach ($selectQuery->result() as $row) {
                    $data[] = $row->slug;
                }
                if (in_array($slug, $data)) {
                    $count = 0;
                    while (in_array(($slug . '-' . ++$count), $data));
                    $slug = $slug . '-' . $count;
                }
            }
            
            $dataInsert = array(
                    'title' => $title, 
                    'parent_id' => $parent_id, 
                    'slug' => $slug, 
                    'short_content' => $short_content,  
                    'status' => $status, 
                    'content' => $content
                );
            if (!empty($slug)) {
                $fName = $slug;
            } else {
                $fName = ucwords($title) . '-' . $this->ci->Categorymodel->generateRandomString(4) . '-' . time();
            }
            if ($_FILES['category_image']['name']!=='') {
                $config['upload_path'] = 'assets/storage/services/category/icon/';
                $config['file_name'] = $fName;
                $config['allowed_types'] = 'jpg|png|jpeg|svg';
                $config['max_size'] = 15000;
                $config['detect_mime'] = true;
                $config['overwrite'] = FALSE;
                $config['max_filename'] = 300;
                $config['encrypt_name'] = FALSE;
                $config['remove_spaces'] = TRUE;
                $this->load->library('upload', $config);
                $this->upload->initialize($config);
                $this->upload->do_upload('category_image');
                $Packageicon = $this->upload->data();
                $dataInsert['category_icon'] = $Packageicon['file_name'];
            }
            $res = $this->db->insert('tbl_category', $dataInsert);
            if ($res == true) {
                $this->session->set_flashdata(['status' => 'Report! Category has been Added successfully!']);
                redirect('Admin/Category/add');
            } else {
                $this->session->set_flashdata(['error' => "Danger! Category has Con't Added successfully!"]);
                redirect('Admin/Category/add');
            }
        }
    }
    
    public function edit($id)
    {
        $datacategoery2 = $this->ci->Categorymodel->getCategoriesByParentId();    
        $datacategoery = $this->ci->Categorymodel->getModuleById('tbl_category',$id);
        $this->load->view('admin/categoryEdit',compact('datacategoery','datacategoery2'));
    }
    public function updateData()
    {
        $id = $this->security->xss_clean($this->input->POST('id'));
        $this->form_validation->set_error_delimiters('<strong>Danger!</strong> ',);
        $this->form_validation->set_rules('title', 'Title', 'trim|required');
        $this->form_validation->set_rules('slug', 'Slug', 'trim|required');
        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata(['error' => validation_errors() ]);
            redirect(base_url('Admin/Category/edit/'.$id));
            exit();
        } else {
            $title = $this->security->xss_clean($this->input->POST('title'));
            $short_content = $this->security->xss_clean($this->input->POST('short_content'));
            $status = $this->security->xss_clean($this->input->POST('status'));
            $content = $this->security->xss_clean($this->input->POST('content'));
            $parent_id = $this->security->xss_clean($this->input->POST('parent_id'));

            //Blog
            $url = $this->security->xss_clean($this->input->POST('slug'));
            $datacategoery = $this->ci->Categorymodel->getModuleById('tbl_category',$id);
            if (empty($url)) {
                $url = $title;
            }
            $slug = preg_replace('/[^a-z0-9]+/i', '-', trim(strtolower($url)));
            $selectQuery = $this->db->query("SELECT * FROM `tbl_category` WHERE slug LIKE '$slug%'");
            if ($datacategoery->slug != $slug) {
                if ($selectQuery->num_rows() > 0) {
                    foreach ($selectQuery->result() as $row) {
                        $data[] = $row->slug;
                    }
                    if (in_array($slug, $data)) {
                        $count = 0;
                        while (in_array(($slug . '-' . ++$count), $data));
                        $slug = $slug . '-' . $count;
                    }
                }
            } else {
                $slug = $slug;
            }
            //End Blog
            $dataInsert = array(
                'title' => $title, 
                'parent_id' => $parent_id, 
                'slug' => $slug, 
                'short_content' => $short_content,
                'status' => $status, 
                'content' => $content
            );
            if (!empty($slug)) {
                $fName = $slug;
            } else {
                $fName = ucwords($title) . '-' . $this->ci->Categorymodel->generateRandomString(4) . '-' . time();
            }
            if ($_FILES['category_image']['name']!=='') {
                $config['upload_path'] = 'assets/storage/services/category/icon/';
                $config['file_name'] = $fName;
                $config['allowed_types'] = 'jpg|png|jpeg|svg';
                $config['max_size'] = 15000;
                $config['detect_mime'] = true;
                $config['overwrite'] = FALSE;
                $config['max_filename'] = 300;
                $config['encrypt_name'] = FALSE;
                $config['remove_spaces'] = TRUE;
                $this->load->library('upload', $config);
                $this->upload->initialize($config);
                $this->upload->do_upload('category_image');
                $Packageicon = $this->upload->data();
                $dataInsert['category_icon'] = $Packageicon['file_name'];

                if ($datacategoery->category_icon && file_exists('assets/storage/services/category/icon/'.$datacategoery->category_icon)) {
                    unlink("assets/storage/services/category/icon/".$datacategoery->category_icon);
                }
            }
            $res = $this->db->where('id', $id)->set($dataInsert)->update('tbl_category');
            if ($res == true) {
                $this->session->set_flashdata(['status' => 'Report! changes has been saved.']);
                redirect(base_url('Admin/Category/edit/'.$id));
            } else {
                $this->session->set_flashdata(['error' => "Report! changes has Con't been saved."]);
                redirect(base_url('Admin/Category/edit/'.$id));
            }

        }
    }
    
    public function home($id)
    {
        $res = $this->ci->Categorymodel->changeStatus('tbl_category' ,'status' ,$id);
        if ($res == true) {
            $this->session->set_flashdata(['error' => "Report! changes has Con't  been saved."]);
            redirect(base_url('Admin/Category/'));
        } else {
            $this->session->set_flashdata(['status' => "Report! changes has been saved."]);
            redirect(base_url('Admin/Category/'));
        }
    }
    public function Delect($id)
    {
        $datacategoery = $this->ci->Categorymodel->getModuleById('tbl_category',$id);
        unlink("assets/storage/services/category/icon/".$datacategoery->category_icon);
        $res = $datacategoery = $this->ci->Categorymodel->delete('tbl_category',$id);
        if ($res == true) {
            $this->session->set_flashdata(['error' => "Report! changes has Con't  been saved."]);
            redirect(base_url('Admin/Category/'));
        } else {
            $this->session->set_flashdata(['status' => "Report! changes has been saved."]);
            redirect(base_url('Admin/Category/'));
        }
    }

 
}
