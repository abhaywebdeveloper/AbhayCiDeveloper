<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Adminmodel extends CI_Model
{

    public function getAll($table)
    {
        $this->db->select()->from($table);
        $this->db->order_by('id', 'desc');
        $query = $this->db->get();
        return $query->result_array();
    }

    public function getByID($id)
    {
        $this->db->select()->from('hm_flash');
        $this->db->where('id', $id);
        $query = $this->db->get();
        return $query->row();
    }

    public function deleteByID($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('hm_flash');
        return $this->db->affected_rows();
    }

    public function changeStatus($id)
    {
        $module = 'hm_flash';
        if (!empty($module) && !empty($id)) {
            $this->db->select("status");
            $this->db->from($module);
            $this->db->where($module . '.id', $id);
            $data = $this->db->get()->row_array();
            $status = !empty($data['status']) ? 0 : 1;
            $this->db->set('status', $status);
            $this->db->where('id', $id);
            $this->db->update($module);
        }
    }
    public function getDataById($table,$id)
    {
        $this->db->select()->from($table);
        $this->db->where('id', $id);
        $query = $this->db->get();
        return $query->row();
    }
}
