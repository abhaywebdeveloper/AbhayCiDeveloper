

<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Categorymodel extends CI_Model
{

	function GetPackage(){
		$data=$this->db->get('tbl_category');
		return $data->result_array();		
	}
	function GetPackageByID($id){
		$this->db->select("parent_id,title,id");
		$this->db->where('parent_id', $id);
		$data=$this->db->get('tbl_category');
		return $data->result_array();		
	}
	function getCategoriesByParentId() {
		$this->db->select("parent_id,title,id");
		$data=$this->db->get('tbl_category');
		return $data->result_array();	
	}

	

	function GetCategoryByID($id)
	{
		$this->db->select("parent_id,title,id");
		$this->db->from('tbl_category');
		$this->db->where('tbl_category' . '.id', $id);
		return $this->db->get()->row();
	}
	
	
	public function changeStatus($TableName = "", $fildName = "", $id ="")
	{
		if (!empty($TableName) && !empty($id)) {
			$this->db->select($fildName);
			$this->db->from($TableName);
			$this->db->where($TableName . '.id', $id);
			$data = $this->db->get()->row_array();
			$status = !empty($data[$fildName]) ? 0 : 1;

			$this->db->set($fildName, $status);
			$this->db->where('id', $id);
			$this->db->update($TableName);
		}
	}

	public function delete($TableName="", $id="")
	{
		if (!empty($TableName) && !empty($id)) {
			$this->db->where('id', $id);
			$this->db->delete($TableName);
		}
	}
	
	

	public function getModuleById($TableName = "", $id = 0)
	{
		$this->db->select("*");
		$this->db->from($TableName);
		$this->db->where($TableName . '.id', $id);
		return $this->db->get()->row();
	}
	



	public function saveModule($TableName = '', $data = [])
	{
		$TableName = $this->checkModuleTable($TableName);
		$this->db->insert($TableName, $data);
		return $this->db->insert_id();
	}

	public function updateModule($TableName = '', $data = [])
	{
		$TableName = $this->checkModuleTable($TableName);
		$this->db->where('id', $data['id']);
		$this->db->update($TableName, $data);
	}

    function generateRandomString($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }    

	//website 

	public function getModuleByFild($TableName = "" ,$whereColumn = "", $whereColumnid = 0)
	{
		$this->db->select('*');
		$this->db->from($TableName);
		$this->db->where($TableName . '.'.$whereColumn, $whereColumnid);
		return $this->db->get()->result_array();
	}
	


	public function getModuleBycolumn($TableName = "", $column = "", $whereColumn = "", $id = 0)
	{
		$this->db->select($column);
		$this->db->from($TableName);
		$this->db->where('status=','1');
		$this->db->where($TableName . '.'.$whereColumn, $id);
		return $this->db->get()->result_array();
	}
	public function getall($TableName = "")
	{
		$this->db->select('*');
		$this->db->from($TableName);
		$this->db->where('status=','1');
		return $this->db->get()->result_array();
	}	
	public function getBySlug($TableName,$slug = "")
    {
        $this->db->select()->from($TableName);
        $this->db->where('slug', $slug);
        $this->db->where('status', 1);
        $query = $this->db->get();
        return $query->row();
    }
	public function getById($TableName,$fildname,$filddata)
    {
        $this->db->select()->from($TableName);
        $this->db->where($fildname, $filddata);
        $this->db->where('status', 1);
        $query = $this->db->get();
        return $query->result_array();
    }
}