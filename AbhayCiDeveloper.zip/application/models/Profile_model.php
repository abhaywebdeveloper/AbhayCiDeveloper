<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Profile_model extends CI_Model {
    private $table;
    public function __construct() {
        parent::__construct();
        $this->table="users";
    }

    function countCustomerAddress(){
        $total = 0;
        $fields = "count(id) as totalCustomerAddress";
        $this->db->select($fields);
        $this->db->from('tbl_address');
        $this->db->where('user_id',$this->session->userdata('userId'));
        $query = $this->db->get();
        if($query->num_rows() > 0){
            $row = $query->row_array();
            $total = $row['totalCustomerAddress'];
        }
        return $total;
    }
    function getAllUserAddress($postVal=array())
	{
		$result = array();
		$fields = "*";
		$this->db->select($fields);
		$this->db->from('tbl_address');
		$this->db->where('user_id',$this->session->userdata('userId'));
		$this->db->order_by('id', 'DESC');
		if(isset($postVal['limit']) && $postVal['limit'] > 0) {
			$this->db->limit($postVal['limit']);
		}
		$query = $this->db->get();
		if($query->num_rows() > 0) {
			$result = $query->result_array();
		}
		return $result;
	}

}