
<!DOCTYPE html>
<html>
    <head>
        <title>Error 404    ||The Monshas</title>
   
  <style>
    body,
    html {
      height: 100%;
      margin: 0;
    }

    .bgimg .middle h1 {
      font-size: 8rem;
      margin: 0px 0px -30px 0px;
    }
    .bgimg .middle a {
      color:#fff;
    }
    
    .pnf {
      font-size: 40px;
      font-weight: 600;
    }

    .bgimg {
      background-color: #000;
      height: 100%;
      background-position: center;
      background-size: cover;
      position: relative;
      color: white;
      font-family: "Courier New", Courier, monospace;
      font-size: 25px;
    }

    .topleft {
      position: absolute;
      top: 0;
      left: 16px;
    }
    .topleft img
    {
        width: 100px;
        height: 100px;
        margin: 20px
    }

    .bottomleft {
      position: absolute;
      bottom: 0;
      left: 16px;
    }

    .middle {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      text-align: center;
    }

    hr {
      margin: auto;
      width: 40%;
    }
    .middle span
    {
    font-size: 14px;
    text-align: center;
    
    }
  </style>
   </head>
  <body>
    <div class="bgimg">
      <div class="topleft">
          <!-- <a href="<?=base_url()?>">
          <img src="<?=base_url()?>assets/storage/home-files/logo.png" alt="">
          </a> -->
      </div>
      <div class="middle">
        <h1>Error 404
        <span>(
              <?php 
              $str =$this->uri->segment(1);
              echo ucwords(str_ireplace( array( '\'', '"',',' , '-', '<', '>' ), ' ', $str));
              ?> Page )
            </span>
        </h1>
        <hr />
        <p class="pnf">Page Not Found</p>
        <a href="<?=base_url()?>">Home</a>       
      </div>
       <!-- <div class="bottomleft">
        <p>
        </p>
      </div>  -->
    </div>
  </body>
</html>
