<!DOCTYPE html>
<html lang="en">
   <head>
      <title>ABHAY SINGH AMY TASKS</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
      <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
      <link rel="stylesheet" href="<?=base_url()?>assets/website/css/style.css">
   </head>
   <body>
      <header class='mb-4'>
         <div class="container">
            <div class="row">
               <div class="col-md-12 col-sm-12 col-lg-12 col-xl-3">
                  <div class="logo">
                     <a href="/" title="logo"> w3learn Point </a>
                  </div>
                  <div class="mob-menu">
                     <span>
                     <i class="fa fa-bars"></i>
                     </span>
                  </div>
               </div>
               <div class="col-md-12 col-sm-12 col-lg-12 col-xl-9">
                  <div class="main-menu">
                     <ul class="nav">
                        <li><a href="/"> Home </a> </li>
                        <li><a href="#"> Process </a> </li>
                        <li><a href="#"> Blog </a> </li>
                        <li><a href="#"> Contact Us </a> </li>
                     </ul>
                     <ul class="right-nav">
                        <li><a href="#"> <i class="fa fa-user"></i> Log in </a> </li>
                        <li class="active"> <a href="#"> <i class="fa fa-sign-in"></i> Sign up </a> </li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </header>

      <div class="container mt-4"></div>
      <div class="container mt-4 mb-4"> 
      <div class="row mb-4">
            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
               <nav class="sidebar card py-2 mb-4">
                  <ul class="nav flex-column">
                    <h5>Product Category</h5>
                    <?php 
                    foreach($datacategoery as $row)
                    {
                        $id = $row['id'].'<br>';
                        $datacategoeryc = $this->ci->Categorymodel->getModuleByFild('tbl_category','parent_id',$id);
                        ?>
                        <li class="<?php if(!empty($datacategoeryc)) { echo 'nav-item'; } ?>">
                           <a class="nav-link" href="<?=base_url()?>category/<?=$row['slug']?>.html"> 
                                 <?=$row['title']?><?php if(!empty($datacategoeryc)) { echo '<b class="float-end">&raquo;</b>'; } ?>  </a>
                           <?php
                           if(!empty($datacategoeryc))
                           {
                              echo '<ul class="submenu dropdown-menu">';
                           }
                           foreach($datacategoeryc as $rows)
                           {
                              ?>                                
                                 <li><a class="nav-link" href="<?=base_url()?>category/<?=$rows['slug']?>.html"><?=$rows['title']?></a></li>
                              <?php
                           }
                           if(!empty($datacategoeryc))
                           {
                              echo '</ul>';
                           }
                           ?>
                         </li>
                        <?php
                    }
                    ?>     
                  </ul>
               </nav>
            </div>
            <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
            <div class="row">
               <?php 
               foreach($alll as $row)
               {
                  ?>
                        <div class="col-md-4 mt-3">
                            <div class="card" style="width: 17rem;">
                                <img class="card-img-top" src="<?=base_url()?>assets/storage/services/category/icon/<?=$row['category_icon']?>" alt="Card image cap">
                                <div class="card-body">
                                    <h5 class="card-title"><?=$row['title']?></h5>
                                    <p class="card-text"><?=$row['short_content']?></p>
                                    <a href="#" class="btn btn-primary">Go somewhere</a>
                                </div>
                            </div>
                        </div>

                        <?php
               }
               ?>
                        
                        
                    </div>
            </div>
         </div>
</div>

      <footer class="footer-section">
         <div class="container">
            <div class="footer-cta pt-5 pb-5">
               <div class="row">
                  <div class="col-xl-4 col-md-4 mb-30">
                     <div class="single-cta">
                        <i class="fas fa-map-marker-alt"></i>
                        <div class="cta-text">
                           <h4>Find us</h4>
                           <span>1010 Avenue, sw 54321, chandigarh</span>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-4 mb-30">
                     <div class="single-cta">
                        <i class="fas fa-phone"></i>
                        <div class="cta-text">
                           <h4>Call us</h4>
                           <span>9876543210 0</span>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-md-4 mb-30">
                     <div class="single-cta">
                        <i class="far fa-envelope-open"></i>
                        <div class="cta-text">
                           <h4>Mail us</h4>
                           <span>mail@info.com</span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="footer-content pt-5 pb-5">
               <div class="row">
                  <div class="col-xl-4 col-lg-4 mb-50">
                     <div class="footer-widget">
                        <div class="footer-logo">
                           <a href="index.html"><img src="https://www.amysoftech.com/frontendAsset/img/logo/logo.svg" class="img-fluid" alt="logo"></a>
                        </div>
                        <div class="footer-text">
                           <p>Lorem ipsum dolor sit amet, consec tetur adipisicing elit, sed do eiusmod tempor incididuntut consec tetur adipisicing
                              elit,Lorem ipsum dolor sit amet.
                           </p>
                        </div>
                        <div class="footer-social-icon">
                           <span>Follow us</span>
                           <a href="#"><i class="fab fa-facebook-f facebook-bg"></i></a>
                           <a href="#"><i class="fab fa-twitter twitter-bg"></i></a>
                           <a href="#"><i class="fab fa-google-plus-g google-bg"></i></a>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-lg-4 col-md-6 mb-30">
                     <div class="footer-widget">
                        <div class="footer-widget-heading">
                           <h3>Useful Links</h3>
                        </div>
                        <ul>
                           <li><a href="#">Home</a></li>
                           <li><a href="#">about</a></li>
                           <li><a href="#">services</a></li>
                           <li><a href="#">portfolio</a></li>
                           <li><a href="#">Contact</a></li>
                           <li><a href="#">About us</a></li>
                           <li><a href="#">Our Services</a></li>
                           <li><a href="#">Expert Team</a></li>
                           <li><a href="#">Contact us</a></li>
                           <li><a href="#">Latest News</a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-xl-4 col-lg-4 col-md-6 mb-50">
                     <div class="footer-widget">
                        <div class="footer-widget-heading">
                           <h3>Subscribe</h3>
                        </div>
                        <div class="footer-text mb-25">
                           <p>Don’t miss to subscribe to our new feeds, kindly fill the form below.</p>
                        </div>
                        <div class="subscribe-form">
                           <form action="#">
                              <input type="text" placeholder="Email Address">
                              <button><i class="fab fa-telegram-plane"></i></button>
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="copyright-area">
            <div class="container">
               <div class="row">
                  <div class="col-xl-6 col-lg-6 text-center text-lg-left">
                     <div class="copyright-text">
                        <p>Copyright &copy; 2018, All Right Reserved <a href="#">Amy</a></p>
                     </div>
                  </div>
                  <div class="col-xl-6 col-lg-6 d-none d-lg-block text-right">
                     <div class="footer-menu">
                        <ul>
                           <li><a href="#">Home</a></li>
                           <li><a href="#">Terms</a></li>
                           <li><a href="#">Privacy</a></li>
                           <li><a href="#">Policy</a></li>
                           <li><a href="#">Contact</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
   </body>
   <link rel="stylesheet" href="<?=base_url()?>assets/website/js/script.js">
</html>

<style>
    h5
    {
        margin: 0px 0px 0px 10px;
    font-weight: 600;
    }
</style>