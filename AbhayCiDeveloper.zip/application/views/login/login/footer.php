                                    </div>
                                </div>
                            </div>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>

	<!-- core:js -->
	<script src="<?=base_url()?>assets/vendors/core/core.js"></script>
	<!-- endinject -->
  <!-- plugin js for this page -->
	<!-- end plugin js for this page -->
	<!-- inject:js -->
	<script src="<?=base_url()?>assets/vendors/feather-icons/feather.min.js"></script>
	<script src="<?=base_url()?>assets/js/template.js"></script>
	
	<!-- endinject -->
  	<!-- custom js for this page -->
	<!-- end custom js for this page -->
</body>
</html>

<script>
	$(document).on('click', '#loginAdminBtn', function (event) {
         event.preventDefault();
           var action = $("#loginAdminform").attr('action'); 
           var formData = new FormData($("#loginAdminform")[0]);
           //console.log(formData);
            $.ajax({
                url : action,
                data : formData,
                async:false,
                cache:false,  
                contentType : false,
                processData : false,
                type : 'POST',
                dataType : 'json',               
                beforeSend: function () {
                  $('input[type=range]').val("0");
                  $('input[type=range]').removeClass("d-none");
               },
                success: function(resp) {
                    console.log(JSON.stringify(resp));
                    if(resp.status == true)
                    {
						//login
						if(resp.message =='login')
						{
							var getUrl = window.location;
							var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
							window.location.replace("<?=base_url('Admin/dashboard')?>");
						}
                    }
                    if(resp.status == false)                     
                     {
                        $.each(resp.message,function(i,m){
                              //console.log(m.toString());
                              $('input[name=\''+i+'\'').attr('placeholder',m); 
                              $('input[name=\''+i+'\'').addClass('is-invalid');
                              $('input[name=\''+i+'\'').parent().append("<div class='alert alert-danger fade show alertbox'> <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> "+m+" </div>");
                              $('input[name=\''+i+'\'').parent().find(".alertbox").flash_msg(1500);
                        });
                     }
                   
                }
            });
        });
       $.fn.flash_msg=function(duration){
         this.fadeIn().delay(duration).fadeOut(function(){
            this.remove();
         })
         }
</script>