<?php
   $errors = $this->session->flashdata();
   include 'include/head.php';
   include 'include/left-header.php';
   include 'include/top-header.php';
   ?>
<div class="page-content">
   <div class="row mb-3">
      <div class="col-md-8">
         <h6 class="card-title">
            <i class="fa fa-tags fw"></i>
            Category
         </h6>
      </div>
      <div class="col-md-4">
         <div class="Add-bottom">
            <a href="<?=base_url('Admin/Category/add')?>" class="btn btn-primary"  title="Add new">
                <i data-feather="plus"></i>
            </a>
            <a href="<?=base_url('Admin/Category')?>" class="btn btn-light"  title="Refresh Pages">
                <i data-feather="refresh-ccw"></i>
            </a>
         </div>
      </div>
   </div>
   <?php if (!empty($errors['error'])): ?>
   <div class="alert alert-fill-warning alert-dismissible fade show mt-1" role="alert">
      <strong> <?=$errors['error']?></strong>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="btn-close"></button>
   </div>
   <?php endif;?>
   <?php if (!empty($errors['status'])): ?>
   <div class="alert alert-success alert-dismissible fade show mt-1" role="alert">
      <strong> <?=$errors['status']?></strong>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="btn-close"></button>
   </div>
   <?php endif;?>
   <div class="row">
      <div class="col-md-12 grid-margin stretch-card">
         <div class="card">
            <div class="card-body">
               <h6 class="card-title">Data Table</h6>
               <div class="table-responsive">
                  <table id="dataTableExample" class="table">
                     <thead>
                        <tr>
                           <th>S.N</th>
                           <th>Name</th>
                           <th>Status</th>
                           <th>image</th>
                           <th>Date</th>
                           <th>Action</th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php 
                        $sn=0;
                        foreach($datacategoery as $rows)
                        {
                           $sn++;
                           ?>
                           <tr>
                              <td><?=$sn?></td>
                              <td><?=$rows['title']?></td>
                              <td>
                                    <a href="<?=base_url('Admin/Category/home')?>/<?=$rows['id']?>" >
                                    <?php if($rows['status']==1)
                                       {
                                          echo '<i class="text-success " data-feather="toggle-left"></i>';
                                       }
                                       else{
                                          echo '<i class="text-danger " data-feather="toggle-right"></i>';
                                       }
                                       ?> 
                                    </a>  
                              </td>
                              <td>
                              <img src="<?=base_url()?>assets/storage/services/category/icon/<?=$rows['category_icon']?>"
                                 style="width: 70px;height: 70px;object-fit: contain;">
                              </td>
                              <td>
                                    <?php
                                       echo date('d M Y', strtotime($rows['created_at']))
                                    ?>
                              </td>
                              <td>
                                 <div class="d-flex justify-content-start">
                                 <a href="<?=base_url()?>Admin/Category/edit/<?=$rows['id']?>"
                                    class="btn btn-outline-success ">
                                 <i data-feather="edit-2"></i> Edit
                                 </a>
                                 <a href="<?=base_url()?>Admin/Category/Delect/<?=$rows['id']?>"
                                    class=" btn btn-outline-danger mrr">
                                 <i data-feather="minus-circle"></i> Delect
                                 </a>
                                 </div>
                              </td>
                           </tr>
                           <?php
                        }
                        ?>
                       
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php
   include 'include/footer.php';
   
   ?>
<style type="text/css">
   .Add-bottom {
   margin-left: 200px;
   }
   .Add-bottom a i {
   margin-right: 10px;
   }
   .mrr {
   margin-left: 10px;
   }
</style>
<script>
   // $(document).on('click','#trinding',function(event) {
   //        event.preventDefault();
   //          var Blogid = $(this).data('id');
   //          var iconid = $(this).find('p:first').data('id');
   //          var thref = $(this).attr('href');
   //          var classname = $(this).find('svg').attr('class');
   //          $.ajax({
   //                   method: "POST",
   //                   url: thref,
   //                    data: {
   //                      Blogid: Blogid
   //                    },
   //                    beforeSend:function(){
   //                      $('.stockcar_wrap').html('loding');
   //                   },
   //                   success: function(html) {   
   //                      if(iconid==0)
   //                      {
   //                         $(this).find('svg').removeClass();
   //                         $(this).find('svg').addClass('feather feather-eye text-success');
   //                      }
   //                      else{
   //                         $(this).find('svg').removeClass();
   //                         $(this).find('svg').addClass('feather feather-eye-off text-danger');
   //                       }
   //                     console.log(iconid);     
   //                    $('#result_blog').html(html);
   //                   }
   //                });

   // });
</script>
