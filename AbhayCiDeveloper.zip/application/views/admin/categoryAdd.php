<?php 
   $errors = $this->session->flashdata();  
     include('include/head.php');
     include('include/left-header.php');
     include('include/top-header.php');
     ?>
<div class="page-content">
   <div class="row mb-3">
      <div class="col-md-8">
         <h6 class="card-title">
            <i class="fa fa-tags fw"></i>
            Category    
         </h6>
      </div>
      <div class="col-md-4">
         <div class="d-flex justify-content-space-between">
            <button type="submit" form-id="form-category" class="btn btn-primary save" id="category_submit" value="Do you really want to Add Category">
            <i class="fa fa-save"></i>
            Save 
            </button>           
            <a href="<?=base_url('Admin/Category')?>" class="btn btn-danger "><i class="fa fa-undo"></i> Back</a>
         </div>
      </div>
      <?php if(!empty($errors['status'])) :?>
      <div class="alert alert-success alert-dismissible fade show mt-1" role="alert">
         <strong> <?=$errors['status']?></strong>
         <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="btn-close"></button>
      </div>
      <?php endif; ?>
      <?php if(!empty($errors['error'])) :?>
      <div class="alert alert-fill-warning alert-dismissible fade show mt-1" role="alert">
         <strong> <?=$errors['error']?></strong>
         <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="btn-close"></button>
      </div>
      <?php endif; ?>
   </div>
   <div class="row mt-4">
      <div class="row align-items-start">
         <div class="col-md-12 d-flex ">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
               <li class="nav-item">
                  <a class="nav-link active" id="General-tab" data-bs-toggle="tab" href="#General" role="tab" aria-controls="General" aria-selected="true">General</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" id="Description-tab" data-bs-toggle="tab" href="#Description" role="tab"
                     aria-controls="Description" aria-selected="false">Data</a>
               </li>
             
            </ul>
         </div>
      </div>
      <form action="<?=base_url()?>Admin/Category/insertData" method="post" enctype="multipart/form-data" id="form-category" class="form-horizontal">
         <input type="hidden" name="<?= $this->security->get_csrf_token_name()?>" value="<?= $this->security->get_csrf_hash(); ?>">
         <div class="tab-content border  p-3" id="myTabContent">
            <div class="tab-pane fade active show" id="General" role="tabpanel" aria-labelledby="General-tab">
               <div class="card-body">
                    <div class="form-group required row">
                     <label class="col-sm-2 control-label" for="input-name1">Parent Category</label>
                     <div class="col-sm-10">
                        <select name="parent_id" class="form-control">
                        <option value="0" selected>Parent Category</option>
                            <?php
                            foreach($datacategoery as $rows)
                            {
                            ?>    
                            <option value="<?=$rows['id']?>"><?=$rows['title']?></option>
                            <?php 
                            }
                            ?>
                        </select>
                     </div>
                  </div>
                
                 <div class="form-group required row">
                     <label class="col-sm-2 control-label" for="input-name1">Category Name</label>
                     <div class="col-sm-10">
                        <input type="text" name="title" placeholder="Category Name........" id="title" class="form-control">
                     </div>
                  </div>
                  <div class="form-group required row">
                      <label class="col-sm-2 control-label" for="input-name1">Slug Url</label>
                      <div class="col-sm-10">
                          <input type="text" name="slug" placeholder="Slug Url ...." id="slug" class="form-control">
                      </div>
                  </div>
                  <div class="form-group  row">
                     <label class="col-sm-2 control-label" for="input-name1">Short Description</label>
                     <div class="col-sm-10">
                     <textarea name="short_content" rows="5" placeholder="Short Description" class="form-control"></textarea>
                     </div>
                  </div>
                  <div class="form-group row">
                     <label class="col-sm-2 control-label" for="input-status">Status</label>
                     <div class="col-sm-10">
                        <select name="status" id="input-status" class="form-control">
                           <option class="text-success" value="1" >Enabled</option>
                           <option class="text-danger" value="0" >Disabled</option>
                        </select>
                     </div>
                  </div>
               </div>
            </div>
            <div class="tab-pane fade" id="Description" role="tabpanel" aria-labelledby="Description-tab">
            <div class="row">
                  <div class="col-md-4">
                     <div class="form-group ">
                        <div class="img-thumbnail">
                           <img onclick="document.getElementById('profile').click();" id="profileImg" src="<?=base_url()?>assets/storage/services/placeholder.png">
                           <input type="file" name="category_image" class="d-none" id="profile">
                        </div>
                        <label >Image Size <br> (80 x 80)Pixel</label>
                     </div>
                  </div>
                  <div class="col-md-8">
                     <div class="form-group row">
                        <label class="control-label">Description</label>
                        <textarea class="form-control" placeholder="Description" name="content" id="summernote1" rows="10">
                        </textarea>
                     </div>
                  </div>
               </div>
            </div>
            <div class="tab-pane fade" id="SEO" role="tabpanel" aria-labelledby="SEO-tab">
               <div class="form-group row ">
                  <label class="col-sm-3 control-label" for="input-meta-title1">Meta Tag Title</label>
                  <div class="col-sm-9">
                     <input type="text" name="meta_title"  placeholder="Meta Tag Title" id="meta_title" class="form-control">
                  </div>
               </div>
               <div class="form-group row">
                  <label class="col-sm-3 control-label">Meta Tag Description</label>
                  <div class="col-sm-9">
                     <textarea name="meta_description" rows="5" placeholder="Meta Tag Description" class="form-control"> </textarea>
                  </div>
               </div>
               <div class="form-group row">
                  <label class="col-sm-3 control-label" for="input-meta-keyword1">Meta Tag Keywords</label>
                  <div class="col-sm-9">
                     <textarea name="meta_keyword" rows="5" placeholder="Meta Tag Keywords" class="form-control"></textarea>
                  </div>
               </div>
               <div class="form-group row">
                  <label class="col-sm-3 control-label" >Meta Focus Keywords</label>
                  <div class="col-sm-9">
                     <textarea name="meta_focus_keywords" rows="5" placeholder="Meta Focus Keywords" class="form-control"></textarea>
                  </div>
               </div>
            </div>
         </div>
      </form>
   </div>
</div>
<?php
   include('include/footer.php');
   ?>
<style type="text/css">
   
   .form-group
   {
   margin-top: 10px;
   }
   .save
   {
   margin-right: 10px;
   margin-left:150px
   }
   .vvvvvv
   {
   margin-right: 10px;
   }
   #profileImg
   {
      width: 80px;
      height: 80px;
   }
   #fileImg1
   {
     width: 100%;
    height: 150px;
   }
   .img-thumbnail
   {
      width: 150px;
      height: 150px;
      text-align: center;
      padding: 28px;
      line-height: 1.42857;
      background-color: #fff;
      border: 1px solid #ddd;
      border-radius: 3px;
      -webkit-transition: all 0.2s ease-in-out;
      -o-transition: all 0.2s ease-in-out;
      transition: all 0.2s ease-in-out;
      display: inline-block;
   }

   .img-thumbnailbanner
   {      
      width: 100%;
      /* height: 150px; */
      text-align: center;
      line-height: 1.42857;
      background-color: #fff;
      border: 1px solid #ddd;
      border-radius: 3px;
      -webkit-transition: all 0.2s ease-in-out;
      -o-transition: all 0.2s ease-in-out;
      transition: all 0.2s ease-in-out;
      display: inline-block;
   }
   .img-thumbnailvidio {
    width: 100%;
    height: 150px;
    text-align: center;
    line-height: 1.42857;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 3px;
    -webkit-transition: all 0.2s ease-in-out;
    -o-transition: all 0.2s ease-in-out;
    transition: all 0.2s ease-in-out;
    display: inline-block;
   }
   .img-thumbnailvidio .form-control
   {
      margin-top: 110px;
   }
   .ggggg
   {
      width: 100%;
      height: 100%;
   }
</style>
<script >
   $('#summernote1').summernote({
          tabsize: 2,
          height: 300,
          toolbar: [
            ['style', ['style']],
            ['font', ['bold', 'underline', 'clear']],
            ['color', ['color']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['table', ['table']],
            ['insert', ['link', 'picture', 'video']],
          //   ['insert', ['picture', 'video']],
          //   ['insert', ['picture']],
            ['view', ['fullscreen', 'codeview']]
          //   ['view', ['fullscreen']]
          ]
        });
        //Slug Function 
    function convertToSlug(Text, destination) {
        $(destination).val(Text.toLowerCase().replace(/ /g, '-').replace(/[^\w-]+/g, ''));
    }
    $("#title").keyup(function(){
        convertToSlug($(this).val(), "#slug");
    });
</script>