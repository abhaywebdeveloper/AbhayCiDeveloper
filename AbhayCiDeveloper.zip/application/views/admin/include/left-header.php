<nav class="sidebar">
   <div class="sidebar-header">
      <a href="<?=current_url('Admin/dashboard')?>" class="sidebar-brand">Abhay Admin</a>
      <div class="sidebar-toggler not-active"><span></span><span></span><span></span></div>
   </div>
   <div class="sidebar-body">
      <ul class="nav">
         <li class="nav-item nav-category">Main</li>
         <li class="nav-item">
            <a href="<?=base_url('Admin/dashboard')?>" class="nav-link">
            <i class="link-icon" data-feather="box">
            </i><span class="link-title">Dashboard</span></a>
         </li>
         <li class="nav-item nav-category">Product Managment</li>
         <li class="nav-item">
            <a class="nav-link collapsed" data-bs-toggle="collapse" href="#services" role="button"
               aria-expanded="false" aria-controls="services">
               <i class="link-icon" data-feather="align-justify"></i>
               <span class="link-title">Category</span>
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                  stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                  class="feather feather-chevron-down link-arrow">
                  <polyline points="6 9 12 15 18 9"></polyline>
               </svg>
            </a>
            <div class="collapse" id="services">
               <ul class="nav sub-menu">
                  <li class="nav-item">
                     <a href="<?=base_url('Admin/category')?>" class="nav-link">
                     Category
                     </a>
                  </li>
                  
               </ul>
            </div>
         </li>
         
         <li class="nav-item">
            <a class="nav-link collapsed" data-bs-toggle="collapse" href="#authPages" role="button"
               aria-expanded="false" aria-controls="authPages">
               <i class="link-icon" data-feather="user-check"></i>
               <span class="link-title">manu 2</span>
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                  stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                  class="feather feather-chevron-down link-arrow">
                  <polyline points="6 9 12 15 18 9"></polyline>
               </svg>
            </a>
            <div class="collapse" id="authPages">
               <ul class="nav sub-menu">
                  <li class="nav-item">
                     <a href="<?=base_url('Admin/About')?>" class="nav-link">Sub manu 2</a>
                  </li>
               </ul>
            </div>
         </li>
        
         
      </ul>
   </div>
</nav>