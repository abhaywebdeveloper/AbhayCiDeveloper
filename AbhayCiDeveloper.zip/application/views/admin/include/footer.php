<footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-between px-4 py-3 border-top small">
   <p class="text-muted mb-1 mb-md-0">Copyright © 2021 <a href="#" target="_blank">The Monshas Salon</a>.</p>
</footer>
</div>
</div>
<script src="<?=base_url()?>assets/js/admin-js/jquery-3.3.1.min.js"></script>
<script src="<?=base_url()?>assets/vendors/core/core.js"></script>
<script src="<?=base_url()?>assets/vendors/chartjs/Chart.min.js"></script>
<script src="<?=base_url()?>assets/vendors/jquery.flot/jquery.flot.js"></script>
<script src="<?=base_url()?>assets/vendors/jquery.flot/jquery.flot.resize.js"></script>
<script src="<?=base_url()?>assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script src="<?=base_url()?>assets/vendors/apexcharts/apexcharts.min.js"></script>
<script src="<?=base_url()?>assets/vendors/feather-icons/feather.min.js"></script>
<script src="<?=base_url()?>assets/js/admin-js/jquery-confirm.js"></script>
<script src="<?=base_url()?>assets/js/template.js"></script>
<script src="<?=base_url()?>assets/js/dashboard-dark.js"></script>
<script src="<?=base_url()?>assets/js/datepicker.js"></script>
<script src="<?=base_url()?>assets/vendors/datatables.net/jquery.dataTables.js"></script>
<script src="<?=base_url()?>assets/vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
<script src="<?=base_url()?>assets/js/data-table.js"></script>
<!-- Plugin js for this page -->
<script src="<?=base_url()?>assets/vendors/ace-builds/src-min/ace.js"></script>
<script src="<?=base_url()?>assets/vendors/ace-builds/src-min/theme-chaos.js"></script>
<script src="<?=base_url()?>assets/js/ace.js"></script>

<script src="<?=base_url()?>assets/vendors/owl.carousel/owl.carousel.min.js"></script>
<script src="<?=base_url()?>assets/vendors/jquery-mousewheel/jquery.mousewheel.js"></script>
<script src="<?=base_url()?>assets/js/carousel.js"></script>

<!-- End plugin js for this page -->
<!-- Custom js for this page -->

<!--
<script src="<?=base_url()?>assets/js/tinymce.js"></script>
 <script src="<?=base_url()?>assets/vendors/tinymce/tinymce.min.js" referrerpolicy="origin"></script>
<script src="https://cdn.tiny.cloud/1/a99g5fwjkqb1x84tybwqefbit62mnkoc9w97hvfwz1fxlary/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>

<script src="<?=base_url()?>assets/js/simplemde.js"></script>
<script src="<?=base_url()?>assets/vendors/simplemde/simplemde.min.js"></script>
<script src="<?=base_url()?>assets/ckeditor/ckeditor.js"></script> -->


<script src="<?=base_url()?>assets/js/admin-js/custome.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>



<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>


</body>
</html>