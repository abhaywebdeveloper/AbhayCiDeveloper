
<!DOCTYPE html>
<html>
  <style>
    body,
    html {
      height: 100%;
      margin: 0;
    }

    .bgimg .middle h1 {
      font-size: 8rem;
    }

    .bgimg {
      background-color: #000;
      height: 100%;
      background-position: center;
      background-size: cover;
      position: relative;
      color: white;
      font-family: "Courier New", Courier, monospace;
      font-size: 25px;
    }

    .topleft {
      position: absolute;
      top: 0;
      left: 16px;
    }

    .bottomleft {
      position: absolute;
      bottom: 0;
      left: 16px;
    }

    .middle {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      text-align: center;
    }

    hr {
      margin: auto;
      width: 40%;
    }
    .bgimg .middle a {
      color:#fff;
    }
    .topleft img
    {
        width: 100px;
        height: 100px;
        margin: 20px
    }
    .middle span
    {
    font-size: 14px;
    margin-left: -74px;
    }
  </style>
  <body>
    <div class="bgimg">
      <div class="topleft">
        <!-- <a href="<?=base_url()?>">
          <img src="<?=base_url()?>assets/storage/home-files/<?=$data_logo->file?>" alt="">
        </a> -->
      </div>
      <div class="middle">
        <h1>COMING SOON 
            <span>(
              <?php 
              $str =$this->uri->segment(1);
              echo ucwords(str_ireplace( array( '\'', '"',',' , '-', '<', '>' ), ' ', $str));
              ?> Page )
            </span>
        </h1>
        <hr />
        <a href="<?=base_url()?>">Home</a>         
      </div>      
    </div>
  </body>
</html>
