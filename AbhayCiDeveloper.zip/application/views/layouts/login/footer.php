                                    </div>
                                </div>
                            </div>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>

	<!-- core:js -->
	<script src="<?=base_url()?>assets/vendors/core/core.js"></script>
	<!-- endinject -->
  <!-- plugin js for this page -->
	<!-- end plugin js for this page -->
	<!-- inject:js -->
	<script src="<?=base_url()?>assets/vendors/feather-icons/feather.min.js"></script>
	<script src="<?=base_url()?>assets/js/template.js"></script>
	
	<!-- endinject -->
  	<!-- custom js for this page -->
	<!-- end custom js for this page -->
</body>
</html>