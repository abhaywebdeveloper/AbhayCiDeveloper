<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php 
	$page = $this->uri->segment(2);

$Auth = $this->session->userdata();?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title><?php echo ucwords($page); ?>| Luxurycarsemporio</title>
	<!-- core:css -->
	<link rel="shortcut icon" href="<?=base_url()?>assets/images/favicon.png" />
	<link rel="stylesheet" href="<?=base_url()?>assets/vendors/core/core.css">
	<link rel="stylesheet" href="<?=base_url()?>assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.css">
	<link rel="stylesheet" href="<?=base_url()?>assets/fonts/feather-font/css/iconfont.css">
	<link rel="stylesheet" href="<?=base_url()?>assets/css/demo_5/style.css">
	<link rel="stylesheet" href="<?=base_url()?>assets/css/demo_5/all.min.css">
	<link rel="stylesheet" href="<?=base_url()?>assets/css/demo_5/jquery-confirm.css">
	<link rel="stylesheet" href="<?=base_url()?>assets/css/demo_5/toastr.min.css">
  	
  <style>	
	.w-8{width:2rem}.object-cover{-o-object-fit:cover;object-fit:cover}.h-8{height:2rem}.rounded-full{border-radius:9999px}.close{position:absolute;right:0;top:-15px}#profileImg{cursor:pointer;border-radius:35px;width:70px;height:70px;object-fit:cover}.camera{position:absolute;top:65px;left:60px}.camera i{font-size:15px;color:#565050;background:#ffffffab;padding:5px;border-radius:50%}
</style>
</head>
<body>
	<div class="main-wrapper">
        <div class="horizontal-menu">
			<nav class="navbar top-navbar">
				<div class="container">
					<div class="navbar-content">
						<a href="<?=current_url()?>" class="navbar-brand">
							Orrish<span> It </span>
						</a>
						<form class="search-form">
							<div class="input-group">
								<div class="input-group-prepend">
									<div class="input-group-text">
										<i data-feather="search"></i>
									</div>
								</div>
								<input type="text" class="form-control" id="navbarForm" placeholder="Search here...">
							</div>
						</form>
						<ul class="navbar-nav">
							
							<li class="nav-item dropdown nav-notifications">
								<a class="nav-link dropdown-toggle" href="#" id="notificationDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									<i data-feather="bell"></i>
									<div class="indicator">
										<div class="circle"></div>
									</div>
								</a>
								<div class="dropdown-menu" aria-labelledby="notificationDropdown">
									<div class="dropdown-header d-flex align-items-center justify-content-between">
										<p class="mb-0 font-weight-medium">6 New Notifications</p>
										<a href="javascript:;" class="text-muted">Clear all</a>
									</div>
									<div class="dropdown-body">
										<a href="javascript:;" class="dropdown-item">
											<div class="icon">
												<i data-feather="user-plus"></i>
											</div>
											<div class="content">
												<p>New customer registered</p>
												<p class="sub-text text-muted">2 sec ago</p>
											</div>
										</a>
										<a href="javascript:;" class="dropdown-item">
											<div class="icon">
												<i data-feather="download"></i>
											</div>
											<div class="content">
												<p>Download completed</p>
												<p class="sub-text text-muted">6 hrs ago</p>
											</div>
										</a>
									</div>
									<div class="dropdown-footer d-flex align-items-center justify-content-center">
										<a href="javascript:;">View all</a>
									</div>
								</div>
							</li>
							<li class="nav-item dropdown nav-profile">
								<a class="nav-link dropdown-toggle" href="javascript:;" id="profileDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								<?php if($Auth['profile'] != null): ?>
                                    <img src="<?=base_url()?>assets/storage/profile/<?=$Auth['profile']?>" alt="<?=$Auth['name']?>">
                                <?php else: ?>
                                    <img class="profile-pic" src="https://ui-avatars.com/api/?name=<?= explode(' ',$Auth['name'])[0] ?>+<?php if(isset(explode(' ',$Auth['name'])[1])) echo explode(' ',$Auth['name'])[1]; ?>&color=7F9CF5&background=EBF4FF" alt="<?=$Auth['name']?>">
                                <?php endif; ?>	
								
								</a>
								<div class="dropdown-menu" aria-labelledby="profileDropdown">
									<div class="dropdown-header d-flex flex-column align-items-center">
										<div class="info text-center">
											<p class="name font-weight-bold mb-0"><?=$Auth['name']?></p>
											<p class="email text-muted mb-3"><?=$Auth['email']?></p>
										</div>
									</div>
									<div class="dropdown-body">
										<ul class="profile-nav p-0 pt-3">
											<li class="nav-item">
												<a href="<?=base_url('profile')?>" class="nav-link">
													<i data-feather="user"></i>
													<span>Profile</span>
												</a>
											</li>
											<li class="nav-item">
												<a href="<?=base_url('logout')?>" class="nav-link">
													<i data-feather="log-out"></i>
													<span>Log Out</span>
												</a>
											</li>
										</ul>
									</div>
								</div>
							</li>
						</ul>
						<button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="horizontal-menu-toggle">
							<i data-feather="menu"></i>					
						</button>
					</div>
				</div>
			</nav>
			<nav class="bottom-navbar">
				<div class="container">
					<ul class="nav page-navigation">
						<li class="nav-item">
							<a class="nav-link" href="<?=base_url()?>/admin">
								<i class="link-icon" data-feather="box"></i>
								<span class="menu-title">Dashboard</span>
							</a>
						</li>
						<li class="nav-item">
							<a href="#" class="nav-link">
								<i class="link-icon" data-feather="mail"></i>
								<span class="menu-title">Email</span>
								<i class="link-arrow"></i>
							</a>
							<div class="submenu">
								<ul class="submenu-item">
									<li class="category-heading">Email</li>
									<li class="nav-item"><a class="nav-link" href="pages/email/inbox.html">Inbox</a></li>
									<li class="nav-item"><a class="nav-link" href="pages/email/read.html">Read</a></li>
									<li class="nav-item"><a class="nav-link" href="pages/email/compose.html">Compose</a></li>
									<li class="category-heading">Other<li>
									<li class="nav-item"><a class="nav-link" href="pages/apps/chat.html">Chat</a></li>
									<li class="nav-item"><a class="nav-link" href="pages/apps/calendar.html">Calendar</a></li>
								</ul>
							</div>
						</li>
						<li class="nav-item">
							<a href="#" class="nav-link">
								<i class="link-icon" data-feather="box"></i>
								<span class="menu-title">Product</span>
								<i class="link-arrow"></i>
							</a>
							<div class="submenu">
								<ul class="submenu-item">
									<li class="category-heading">Category</li>
									<li class="nav-item">
										<a class="nav-link" href="<?=base_url()?>admin/add-category">Add Category </a></li>
									<li class="nav-item">
										<a class="nav-link" href="<?=base_url()?>admin/show-category">Show Category</a></li>
									<!--	<li class="category-heading">Sub Category</li>
									 <li class="nav-item">
										<a class="nav-link" href="<?=base_url()?>/admin">Add Sub Category </a></li>
									<li class="nav-item">
										<a class="nav-link" href="<?=base_url()?>/admin">Show Sub Category</a></li> -->
									<li class="category-heading">Product<li>
									<li class="nav-item"><a class="nav-link" href="<?=base_url()?>admin/add-product">Add Product</a></li>
									<li class="nav-item"><a class="nav-link" href="<?=base_url()?>admin/show-product">Show Product</a></li>
								</ul>
							</div>
						</li>
					</ul>
				</div>
			</nav>
		</div>
		<!-- partial -->
        <div class="page-wrapper">
        	<!------------------------------------Orrish It --------------------->