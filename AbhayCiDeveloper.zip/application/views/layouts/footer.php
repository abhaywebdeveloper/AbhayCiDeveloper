
			<!-- partial:partials/_footer.html -->
			<footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-between">
				<p class="text-muted text-center text-md-left">Copyright © 2020 <a href="<?=base_url()?>admin" target="_blank">Admin | Orrish</a>. All rights reserved</p>
				<p class="text-muted text-center text-md-left mb-0 d-none d-md-block">Handcrafted With <i class="mb-1 text-primary ml-1 icon-small" data-feather="heart"></i></p>
			</footer>
			<!-- partial -->
		</div>
	</div>
  <script src="<?=base_url()?>assets/vendors/core/core.js"></script>
  <script src="<?=base_url()?>assets/vendors/chartjs/Chart.min.js"></script>
  <script src="<?=base_url()?>assets/js/jquery-3.4.1.js"></script>
  <script src="<?=base_url()?>assets/vendors/jquery.flot/jquery.flot.js"></script>
  <script src="<?=base_url()?>assets/vendors/jquery.flot/jquery.flot.resize.js"></script>
  <script src="<?=base_url()?>assets/vendors/apexcharts/apexcharts.min.js"></script>
  <script src="<?=base_url()?>assets/vendors/progressbar.js/progressbar.min.js"></script>
  <script src="<?=base_url()?>assets/js/jquery-confirm.js"></script>
  <script src="<?=base_url()?>assets/js/toastr.min.js"></script>
  <script src="<?=base_url()?>assets/vendors/feather-icons/feather.min.js"></script>
  <script src="<?=base_url()?>assets/js/template.js"></script>
  <script src="<?=base_url()?>assets/js/dashboard.js"></script>
  <script src="<?=base_url()?>assets/js/custome.js"></script>  
</body>
</html> 